package solucion;

public class ESinClientes extends Exception {
	
	public ESinClientes () {
		super("La empresa no tiene clientes");
	}
}
