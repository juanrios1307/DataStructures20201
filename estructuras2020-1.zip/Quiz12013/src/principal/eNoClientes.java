package principal;

public class eNoClientes extends Exception {

	
}
