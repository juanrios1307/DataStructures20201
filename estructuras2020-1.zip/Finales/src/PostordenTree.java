import java.util.*;

public class PostordenTree {
    
    public ArrayList<Integer> fromPreordenToPostorden(Integer[] preorden) {
        ArrayList<Integer> preordena=new ArrayList<Integer>();
        preordena.addAll(Arrays.asList(preorden));
        
        ArrayList<Integer> postorden=new ArrayList<Integer>();
        
       subTrees(preordena,postorden,1);
        
        return postorden;
    }
    
    public void subTrees(ArrayList<Integer> tree,ArrayList<Integer> post,int i){
        if(tree.size()==1){
            post.add(tree.remove(0));
        }else if(tree.size()==2){
        	post.add(tree.remove(0));
        	post.add(tree.remove(0));
        }else{
            
            ArrayList<Integer> subtreeIzq=new ArrayList<Integer>();
            ArrayList<Integer> subtreeDer=new ArrayList<Integer>();

            while(i<tree.size() && tree.get(i) < tree.get(0)){
                subtreeIzq.add(tree.remove(i));
                i++;
            }
            int j=i;
            
            while(i<tree.size() && tree.get(i) > tree.get(0)){
                subtreeDer.add(tree.remove(i));
                i++;
            }
            int k=i;
            
            subTrees(subtreeIzq,post,j);
            subTrees(subtreeDer,post,k);
            
        }
    }
    
    
 

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Scanner in = new Scanner(System.in);
        String line= in.nextLine();
        String[] preordenS=line.split(",");
        Integer[] preorden=new Integer[preordenS.length];
        for (int i=0;i<preordenS.length;i++)
            preorden[i]=Integer.parseInt(preordenS[i]);
        PostordenTree p=new PostordenTree();
        //p.preordenpostorden(preorden, 0, preorden.length);
        ArrayList<Integer> resultado=p.fromPreordenToPostorden(preorden);
        for (Integer s:resultado)
            System.out.println(s);
        in.close();
    }

}