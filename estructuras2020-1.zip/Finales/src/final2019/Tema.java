package final2019;

import java.util.ArrayList;

public class Tema {
	
	
	private ArrayList<Video> videos;
	private ArrayList<Recurso> recursos;
	
	
	public Tema(ArrayList<Video> videos, ArrayList<Recurso> recursos) {
		super();
		this.videos = videos;
		this.recursos = recursos;
	}
	
	
	
	
}
