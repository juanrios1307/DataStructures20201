package final2019;

public class Recurso {
	
	private String nombreClase;

	public Recurso(String nombreClase) {
		super();
		this.nombreClase = nombreClase;
	}
	
	
}
