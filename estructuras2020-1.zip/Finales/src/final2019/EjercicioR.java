package final2019;

import java.util.ArrayList;

public class EjercicioR extends Recurso{
	
	
	private String tipo;
	private ArrayList<String> opciones;
	private ArrayList<Boolean> respuestas;
	
	public EjercicioR(String nombreClase, String tipo, ArrayList<String> opciones, ArrayList<Boolean> respuestas) {
		super(nombreClase);
		this.tipo = tipo;
		this.opciones = opciones;
		this.respuestas = respuestas;
	}
	
	
}
