package final2019;

public class Video {
	
	private String nombre,direccion;
	private int orden;
	
	public Video(String nombre, String direccion,int orden) {
		super();
		this.nombre = nombre;
		this.direccion = direccion;
		this.orden=orden;
	}
	
	
}
