package final2019;

public class ArchivosR extends Recurso {

	
	public ArchivosR(String nombreClase) {
		super(nombreClase);
	
	}
	

}
