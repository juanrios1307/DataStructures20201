package final2019;

import java.util.*;

public class Principal {
	
	private ArrayList<Tema> temas;
	private LinkedList<Propaganda> propagandas;

	public Principal(ArrayList<Tema> temas,LinkedList<Propaganda> propagandas) {
		super();
		this.temas = temas;
		this.propagandas=propagandas;
	}
	
	public Principal() {
		temas=new ArrayList<Tema>();
		propagandas= new LinkedList<Propaganda>();
	}
	
	public void addPropaganda(Propaganda p) {
		propagandas.add(p);
		updateRango();
	}
	
	public Propaganda buscarPropaganda(double n) {
		for(int i=0;i<propagandas.size();i++) {
			Propaganda aux=propagandas.get(i);
			if(aux.getrMin()<n && aux.getrMax()>n) {
				return aux;
			}
		}
		return null;
	}
	
	public void eliminarPropaganda(Propaganda p) {
		propagandas.remove(p);
		updateRango();
	}
	
	public void updateRango() {
		double precioTotal=0;
		for(int i=0;i<propagandas.size();i++) {
			precioTotal+=propagandas.get(i).getPrecio();
		}
		double minMax=0;
		for(int i=0;i<propagandas.size();i++) {
			Propaganda aux=propagandas.get(i);
			aux.setProba(aux.getPrecio()/precioTotal);
			
			if(i>0) {
				aux.setProbaAcum(aux.getProba()+propagandas.get(i-1).getProbaAcum());
			}else {
				aux.setProbaAcum(aux.getProba());
			}
			
			aux.setrMin(minMax);
			minMax=aux.getProbaAcum();
			aux.setrMax(minMax);
		}
	}
	
	public LinkedList<Propaganda> proximasPropagandas(int n){
		LinkedList<Propaganda> proximas=new LinkedList<Propaganda>();
		
		for(int i=0;i<n;i++) {
			double r=Math.random();
			System.out.print(r+"\t");
			proximas.add(buscarPropaganda(r));
		}
		System.out.println();
		return proximas;
	}
	
	
	
	public LinkedList<Propaganda> getPropagandas() {
		return propagandas;
	}

	public static void main(String[] args) {
		Principal p=new Principal();
		
		Propaganda p1=new Propaganda(1000);
		Propaganda p2=new Propaganda(500);
		Propaganda p3=new Propaganda(2000);
		Propaganda p4=new Propaganda(800);
		
		p.addPropaganda(p1);
		p.addPropaganda(p2);
		p.addPropaganda(p3);
		p.addPropaganda(p4);
		
		for(int i=0;i<4;i++) {
			System.out.println(p.getPropagandas().get(i));
		}
		
		System.out.println("==========================");
		
		LinkedList<Propaganda> arr=new LinkedList<Propaganda>();
		arr=p.proximasPropagandas(3);
		
		for (int i = 0; i <3; i++) {
			System.out.println(arr.get(i));
		}
		
		
	}
	
}
