package final2019;

public class Propaganda {
	
	
	private double precio,proba,probaAcum,rMin,rMax;
	
	
	
	@Override
	public String toString() {
		return "Propaganda [precio=" + precio + ", proba=" + proba + ", probaAcum=" + probaAcum + ", rMin=" + rMin
				+ ", rMax=" + rMax + "]";
	}

	public Propaganda(double precio) {
		super();
		this.precio = precio;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public double getProba() {
		return proba;
	}

	public void setProba(double proba) {
		this.proba = proba;
	}

	public double getProbaAcum() {
		return probaAcum;
	}

	public void setProbaAcum(double probaAcum) {
		this.probaAcum = probaAcum;
	}

	public double getrMin() {
		return rMin;
	}

	public void setrMin(double rMin) {
		this.rMin = rMin;
	}

	public double getrMax() {
		return rMax;
	}

	public void setrMax(double rMax) {
		this.rMax = rMax;
	}
	
	
}
