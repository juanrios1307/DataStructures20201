package final2018;

public class Multimedia implements Comparable<Multimedia> {
	
	private String tipo,genero,titulo,duracion,nacion,continente;
	private Integer reproducciones,likes;
	
	public Multimedia(String tipo, String genero, String titulo, String duracion, String nacion, String continente,
			int reproducciones, int likes) {
		super();
		this.tipo = tipo;
		this.genero = genero;
		this.titulo = titulo;
		this.duracion = duracion;
		this.nacion = nacion;
		this.continente = continente;
		this.reproducciones = reproducciones;
		this.likes = likes;
	}
	
	@Override
	public int compareTo(Multimedia m1) {
		return m1.getReproducciones().compareTo(reproducciones);
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getDuracion() {
		return duracion;
	}

	public void setDuracion(String duracion) {
		this.duracion = duracion;
	}

	public String getNacion() {
		return nacion;
	}

	public void setNacion(String nacion) {
		this.nacion = nacion;
	}

	public String getContinente() {
		return continente;
	}

	public void setContinente(String continente) {
		this.continente = continente;
	}

	public Integer getReproducciones() {
		return reproducciones;
	}

	public void setReproducciones(int reproducciones) {
		this.reproducciones = reproducciones;
	}

	public int getLikes() {
		return likes;
	}

	public void setLikes(int likes) {
		this.likes = likes;
	}

	
	
	
}
