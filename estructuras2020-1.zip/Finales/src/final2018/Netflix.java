package final2018;

import java.util.LinkedList;
import java.util.PriorityQueue;

public class Netflix {
	
	
	private LinkedList<Multimedia> listaMultimedias;

	public Netflix(LinkedList<Multimedia> listaMultimedias) {
		super();
		this.listaMultimedias = listaMultimedias;
	}
	
	public Netflix() {
		listaMultimedias=new LinkedList<Multimedia>();
	}
	
	public PriorityQueue<Multimedia> ordenarGenero(String genero){
		PriorityQueue<Multimedia> all=new PriorityQueue<Multimedia>();  
		
		for(int i=0;i<listaMultimedias.size();i++) {
			Multimedia aux=listaMultimedias.get(i);
			if(aux.getGenero().compareTo(genero)==0) {
				all.add(aux);
			}
		}
		
		return all;
	}
	
	public LinkedList<Multimedia> getListaMultimedias() {
		return listaMultimedias;
	}

	public void setListaMultimedias(LinkedList<Multimedia> listaMultimedias) {
		this.listaMultimedias = listaMultimedias;
	}
	
	
}
