package final2018;

import java.util.LinkedList;

public class Serie {
	
	private LinkedList<Multimedia> temporadas;

	public Serie(LinkedList<Multimedia> temporadas) {
		super();
		this.temporadas = temporadas;
	}

	public LinkedList<Multimedia> getTemporadas() {
		return temporadas;
	}

	public void setTemporadas(LinkedList<Multimedia> temporadas) {
		this.temporadas = temporadas;
	}

	
	
	
}
