package principal;
import java.io.*;
public class MezclaEquilibradaMultiple {
	
	static final int N = 6;
	static final int N2 = N/2;
	static File archivoOrigen;
	static File []files = new File[N];
	static final int MAX = 999;  //Numero maximo que podra tener el archivo
	public static void main(String[] args){
		 String[] nameFiles = {"fileAux1", "fileAux2", "fileAux3", "fileAux4", "fileAux5", "fileAux6"};
		 archivoOrigen = new File("ArchivoOrigen");
		 for (int i = 0; i < N; i++)
			 files[i] = new File(nameFiles[i]);
		 DataOutputStream flujo = null;
		 
		 // Se hace archivo con un numero de registros 
		 try {
			 flujo = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(archivoOrigen)));
			 for (int i = 1; i <= 149; i++) {
				 flujo.writeInt((int)(1+MAX*Math.random()));
				 //flujo.writeInt(i);
			 }
			 flujo.close();
			 System.out.print("Archivo original: ");
			 escribir(archivoOrigen);
			 mezclaEqMple();
		 }
		 catch (IOException e){
			 System.out.println("Error entrada/salida durante proceso" +" de ordenación ");
			 e.printStackTrace();
		 }
	}
	
	public static void mezclaEqMple(){ //Metodo de mezcla multiple equilibrada diseñado para enteros
		 int anterior;
		 int [] indices = new int[N];
		 int [] indexCambio = new int[N];
		 int [] registros = new int[N2];
		 
		 Object [] arrFlujos = new Object[N];
		 DataInputStream fEntradaActual = null;
		 DataOutputStream fSalidaActual = null;
		 boolean [] activos = new boolean[N2];
		
		 try {
			 int i;
			 // distribución de tramos
			 int t = distribuirTramos();
			 for (i = 0; i < N; i++)
				 indices[i] = i;
			 // cuando numTramos=1 entonces archivo ordenado
			 do {
				 int k = (t < N2) ? t : N2;
				 for (i = 0; i < k; i++){
					 arrFlujos[indices[i]] = new DataInputStream(new BufferedInputStream(new FileInputStream(files[indices[i]])));
					 indexCambio[i] = indices[i];
				 }
				 int j = N2; // índice de archivo de salida
				 t = 0;
				 for (i = j; i < N; i++)
					 arrFlujos[indices[i]] = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(files[indices[i]])));
				 // entrada de una clave de cada flujo
				 for (int n = 0; n < k; n++){
					 fEntradaActual = (DataInputStream)arrFlujos[indexCambio[n]];
					 registros[n] = fEntradaActual.readInt();
				 }
			
				 while (k > 0){
					 t++; // mezcla siguiente tramo
					 for (i = 0; i < k; i++)
						 activos[i] = true;
					 fSalidaActual = (DataOutputStream)arrFlujos[indices[j]];
					 while (!finDeTramos(activos, k)){
						 int n = minimo(registros, activos, k);  //n es indice que guarda el numero minimo del arreglo 
						 fEntradaActual = (DataInputStream)arrFlujos[indexCambio[n]];
						 fSalidaActual.writeInt(registros[n]);
						 anterior = registros[n];
						 try {
							 registros[n] = fEntradaActual.readInt();
							 if (anterior > registros[n]) // final del tramo actual
								 activos[n] = false;
						 }catch (EOFException eof){
							k--;
							fEntradaActual.close();
							indexCambio[n] = indexCambio[k];
							registros[n] = registros[k];
							activos[n] = activos[k];
							activos[k] = false;
						 }
					 }
					
					 j = (j < N-1) ? j+1 : N2; // siguiente flujo de salida
				 }
				 for (i = N2; i < N; i++){
					 fSalidaActual = (DataOutputStream)arrFlujos[indices[i]];
					 fSalidaActual.close();
				 }
				 //Cambio de funcion de flujos
				 for (i = 0; i < N2; i++){
					 int aux;
					 aux = indices[i];
					 indices[i] = indices[i+N2];
					 indices[i+N2] = aux;
				 }
			 } while (t > 1);
			 System.out.print("Archivo ordenado:");
			 escribir(files[indices[0]]);
		 }catch (IOException er){
			 er.printStackTrace();
		 }
	}
	
	//distribuye tramos de flujos de entrada en flujos de salida
	private static int distribuirTramos() throws IOException{
		 DataInputStream flujo = new DataInputStream(new BufferedInputStream(new FileInputStream(archivoOrigen)));
		 DataOutputStream [] flujoSalida = new DataOutputStream[N2];
		 for (int j = 0; j < N2; j++){
			 flujoSalida[j] = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(files[j])));
		 }
		 int min = -MAX;
		 int key = min + 1;
		 int j = 0; // indice del flujo de salida
		 int numTramos = 0;
		 // bucle termina con la excepción fin de fichero
		 try {
			 while (true){
				 key = flujo.readInt();
				 while (min <= key){
					 flujoSalida[j].writeInt(key);
					 min = key;
					 key = flujo.readInt();
				 }
				 numTramos++; // nuevo tramo
				 j = (j < N2-1) ? j+1 : 0; // siguiente archivo
				 flujoSalida[j].writeInt(key);
				 min = key;
			 }
		 }catch (EOFException eof){
			 numTramos++; // cuenta ultimo tramo
			 System.out.println("Número de tramos: " + numTramos + " \n");
			 flujo.close();
			 for (j = 0; j < N2; j++)
				 flujoSalida[j].close();
			 return numTramos;
		 }
	}
	
	//devuelve el índice del menor valor del array de claves
	private static int minimo(int [] registros, boolean [] act, int n){
		 int indice = 0;
		 int m = MAX+1;
		 for (int i=0; i < n; i++){
			 if (act[i] && registros[i] < m){
				 m = registros[i];
				 indice = i;
			 }
		 }
		return indice;
	}
	
	//devuelve true si no hay tramo activo
	private static boolean finDeTramos(boolean [] activo, int n){
		 for(int k = 0; k < n; k++){
			 if (activo[k]) return false;
		 }
		 return true;
	}
	
	//escribe las claves del archivo
	static void escribir(File archivo){
		 DataInputStream flujo = null;
		 try {
			 flujo = new DataInputStream(new BufferedInputStream(new FileInputStream(archivo)));
			 int k = 0;
			 System.out.println();
			 while (true){
				 k++;
				 System.out.print(flujo.readInt() + "\t");
				 
				 if (k == 10 ) {
					 System.out.println();
					 k=0;
				 }
			 }
		 }catch (IOException eof){
			 System.out.println("\n \t\t Fin del archivo\t\t\n");
			 try{
				 if (eof instanceof EOFException)
					 flujo.close();
			 }catch (IOException er){
				 er.printStackTrace();
			 }
		 }
	}
}

