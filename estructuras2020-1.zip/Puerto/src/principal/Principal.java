package principal;

public class Principal {
	public static void main(String[] args) {
		
		Puerto p=new Puerto(1, "Buenaventura");
		
		MercanciaExenta me1=new MercanciaExenta(1, 10, "Yoyos");
		MercanciaPlastica mp1=new MercanciaPlastica(2, 10, "Celulares");
		MercanciaExenta me2=new MercanciaExenta(3,100,"Vasos");
		MercanciaExenta me3=new MercanciaExenta(5,200,"hearPhones");
		MercanciaPlastica mp2=new MercanciaPlastica(2, 10, "Gafas");
		
		
		Mercancia[] m= {me1,me2};
		MercanciaMixta mm1=new MercanciaMixta(4, "Hueco", m);
		
		Mercancia[] m1= {mm1,mp2};
		Mercancia[] m2= {mp1,me3};
		
		
		SolicitudEntrada se1=new SolicitudEntrada(1, m1);
		SolicitudEntrada se2=new SolicitudEntrada(2,m2);
		
		
		Importador imp1=new Importador(1,"Juan");
		imp1.addSolicitud(se1);
		
		Importador imp2=new Importador(2, "Esteban");
		imp2.addSolicitud(se2);
		
		p.addImportador(imp2);
		p.addImportador(imp1);
		
		try {
			System.out.println("El cliente que menos concepto paga por impuesto: "+p.menorImpuesto().getNombre());
		} catch (ESinImportadores e) {
			
			e.printStackTrace();
		}
		
	}
}
