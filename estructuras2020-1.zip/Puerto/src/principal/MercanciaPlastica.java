package principal;

public class MercanciaPlastica extends Mercancia {

	public MercanciaPlastica(int codigo, int peso, String nombre) {
		super(codigo, peso, nombre);
	}

	public double calcularImpuesto() {
		return peso*0.2 ;
	}

}
