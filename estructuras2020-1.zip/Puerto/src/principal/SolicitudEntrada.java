package principal;

import java.util.Date;

public class SolicitudEntrada {
	
	private int codigo;
	private Mercancia[] m;
	private Date fecha=new Date();
	
	public SolicitudEntrada(int codigo, Mercancia[] m) {
		this.codigo=codigo;
		this.m=m;
	}
	
	public double calcularImpuestoMercancia() {
		double impuesto=0;
		
		for (int i = 0; i < m.length; i++) {
			impuesto+=m[i].calcularImpuesto();
		}
		
		return impuesto;
	}
	
}
