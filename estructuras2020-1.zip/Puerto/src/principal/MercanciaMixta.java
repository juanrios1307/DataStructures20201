package principal;

public class MercanciaMixta extends Mercancia {
	Mercancia[] m;
	public MercanciaMixta(int codigo, String nombre, Mercancia[] m) {
		super(codigo, nombre);
		this.m=m;
		
		calcularPeso();
	}
	
	private void calcularPeso() {
		for (int i = 0; i < m.length; i++) {
			peso += m[i].peso;
		}
	}

	public double calcularImpuesto() {
		double imp=0;
		for (int i = 0; i < m.length; i++) {
			imp += m[i].calcularImpuesto();
		}
		return imp;
	}
	
}
