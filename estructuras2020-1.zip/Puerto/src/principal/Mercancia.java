package principal;

public abstract class Mercancia {
	protected int codigo,peso;
	protected String nombre;
	
	public Mercancia(int codigo,int peso, String nombre) {
		this.codigo=codigo;
		this.peso=peso;
		this.nombre=nombre;
	}
	
	public Mercancia(int codigo, String nombre) {
		this.codigo=codigo;
		this.nombre=nombre;
	}
	
	public abstract double calcularImpuesto();
	
}
