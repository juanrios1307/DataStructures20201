package principal;

public class ESinImportadores extends Exception {
	
	public ESinImportadores(){
		super("Sin importadores");
	}
}
