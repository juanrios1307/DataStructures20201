package principal;

import java.util.Arrays;

public class Importador {
	
	private int codigo;
	private String nombre;
	private SolicitudEntrada[] se;
	
	public Importador(int codigo, String nombre) {
		this.codigo=codigo;
		this.nombre=nombre;
		se= new SolicitudEntrada[0];
	}
	
	public void addSolicitud(SolicitudEntrada sol) {
		se=Arrays.copyOf(se, se.length+1);
		se[se.length-1]=sol;
	}
	
	public double calcularCostoSolicitudes() {
		double valor=0;
		for (int i = 0; i < se.length; i++) {
			valor+=se[i].calcularImpuestoMercancia();
		}
		return valor;
	}
	
	public String getNombre() {
		return nombre;
	}
}
