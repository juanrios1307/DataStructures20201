package principal;

import java.util.Arrays;

public class Puerto {
	private int codigo;
	private String nombre;
	private Importador[] imp;
	public Puerto(int codigo, String nombre) {
		this.codigo=codigo;
		this.nombre=nombre;
		imp=new Importador[0];
	}
	
	public void addImportador(Importador i) {
		imp=Arrays.copyOf(imp, imp.length+1);
		
		imp[imp.length-1]=i;
	}
	
	public Importador menorImpuesto() throws ESinImportadores {
		double valor=99999999;
		Importador i=null;
		
		if (imp.length==0) {
			throw new ESinImportadores();
		}
		
		for (int j = 0; j < imp.length; j++) {
			if(imp[j].calcularCostoSolicitudes()<valor) {
				valor=imp[j].calcularCostoSolicitudes();
				i=imp[j];
			}
		}
		return i;
	}
	
	
}
