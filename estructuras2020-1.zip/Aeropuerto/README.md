# Aeropuerto

Project created by 5 students in data structures class, 
Aeropuerto is a compilation of a general function of a real airport with validations of airplanes to give permissions
Aeropuerto have legal functions, how is migration, check of passports, check of ware of planes.
