package datojava.jcalendar;

import java.awt.Color;
import java.util.Date;

import com.toedter.calendar.IDateEvaluator;

public class DJFechasEspInv implements IDateEvaluator{

	@Override
	public Color getInvalidBackroundColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Color getInvalidForegroundColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getInvalidTooltip() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Color getSpecialBackroundColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Color getSpecialForegroundColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getSpecialTooltip() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isInvalid(Date arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSpecial(Date arg0) {
		// TODO Auto-generated method stub
		return false;
	}

}
