package Avion;

import Persona.Mercancia;

public class Carga extends Avion{

	

	public Carga(double capCarga, double combustMax, double consumo, int horasVuelo,String matricula ,String modelo, String aerolinea,
			double nivAceite) {
		super(capCarga, combustMax, consumo, horasVuelo, matricula, modelo, aerolinea, nivAceite);
		
	}
	
	

}
