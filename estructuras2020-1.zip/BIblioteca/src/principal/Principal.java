package principal;

import java.util.Date;

import biblioteca.Bibliotecario;
import biblioteca.Boleta;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				InterfazMain main=new InterfazMain();
				main.setVisible(true);
				
				
		
	}

}
