package cuatroElementos;

public class CompetenciaEquipo extends Competencia {
	
	private Equipo[] equipos;
	private Equipo ganador;


	public CompetenciaEquipo(String nombre, String pista, Equipo[] equipos, Equipo ganador) {
		super(nombre, pista);
		this.equipos = equipos;
		this.ganador = ganador;
	}

	public Equipo[] getEquipos() {
		return equipos;
	}

	public void setEquipos(Equipo[] equipos) {
		this.equipos = equipos;
	}

	public Equipo getGanador() {
		return ganador;
	}

	public void setGanador(Equipo ganador) {
		this.ganador = ganador;
	}
	
	
}
