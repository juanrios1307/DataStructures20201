package cuatroElementos;

public class Equipo {
	private String nombre;
	private Jugador[] jugadores;
	
	public Equipo(Jugador[] jugadores,String nombre) {
		super();
		this.jugadores = jugadores;
		this.nombre=nombre;
	}

	public Jugador[] getJugadores() {
		return jugadores;
	}

	public void setJugadores(Jugador[] jugadores) {
		this.jugadores = jugadores;
	}
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
}
