package cuatroElementos;

public class Jugador {
	/*el nombre, edad y región donde vive.*/
	
	private String nombre,region;
	private int edad;
	
	
	public Jugador(String nombre, String region, int edad) {
		super();
		this.nombre = nombre;
		this.region = region;
		this.edad = edad;
		
	}
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}
	
}
