package cuatroElementos;

public class Competencia {
	/* un nombre, una pista, si es por equipos tiene la lista de equipos que participan y el 
	 * equipo ganador, 
	 * y si es individual tiene la lista de jugadores que participan y el jugador ganador.*/
	
	private String nombre,pista;

	public Competencia(String nombre, String pista) {
		super();
		this.nombre = nombre;
		this.pista = pista;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getPista() {
		return pista;
	}

	public void setPista(String pista) {
		this.pista = pista;
	}
	
	
}
