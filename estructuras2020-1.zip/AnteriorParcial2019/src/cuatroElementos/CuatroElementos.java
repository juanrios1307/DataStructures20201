package cuatroElementos;
public class CuatroElementos {
	
	private CompetenciaEquipo[] competencias;
	private Jugador[] jugador;
	private Equipo[] equipo;

	public CuatroElementos(CompetenciaEquipo[] competencias, Jugador[] jugador, Equipo[] equipo) {
		super();
		this.competencias = competencias;
		this.jugador=jugador;
		this.equipo=equipo;
	}
	
	
	
	/*	a. Que, dado el nombre de un equipo
	 *  y una competencia específica, busque en la lista general de competencias 
	 *  (que debe estar en la clase principal) devuelva verdadero si el equipo participó en ella 
	 *  y falso si no participó (0.8 puntos).
	 */
	
	public boolean buscarEquipo(String equipo, CompetenciaEquipo c) {
		
		for (int i = 0; i < c.getEquipos().length; i++) {
			if(equipo.equals(c.getEquipos()[i].getNombre())) {
				return true;
			}
		}
		return false;
	}
	
	 /*b. Que, dado el nombre de un equipo y el tipo de pista
         (tierra, aire, agua, fuego, inframundo), devuelva el porciento de juegos ganados (0.9 puntos).*/
	
	public double procientoGanadoEquipo(String equipo, String pista) {
		int num=0,partida=0;
		for (int i = 0; i < competencias.length; i++) {
			if(competencias[i].getPista().equals(pista)) {
				if(equipo.equals(competencias[i].getGanador().getNombre())) {
					num++;
				}
				partida++;
			}
			
			
		}

		return (num/partida)*100;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Jugador[] jugadores=new Jugador[20];
		Equipo[] equipos=new Equipo[20];
		
		
		for (int i = 0; i < jugadores.length; i++) {
			jugadores[i]=new Jugador("Juan"+i, "Antioquia", i*2+10);
			
		}
		for (int i = 0; i < equipos.length; i++) {
			equipos[i]=new Equipo(jugadores, "Este"+i);
		}
		
		CompetenciaEquipo[] comps=new CompetenciaEquipo[20];
		
		for (int i = 0; i < equipos.length; i++) {
			comps[i]=new CompetenciaEquipo("c"+i, /*i%2==0?"Aire":i%3==0?"Fuego":i%5==0?"Inframundo":"Agua"*/"Agua", equipos, equipos[1]);
		}
		
		CuatroElementos p=new CuatroElementos(comps,jugadores,equipos);
		
		System.out.println(p.buscarEquipo("Este1", comps[2]));
		System.out.println(p.procientoGanadoEquipo("Este1", "Agua"));
		
	}
	
}
