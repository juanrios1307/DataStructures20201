package cuatroElementos;

public class CompetenciaJugador extends Competencia{
	
	private Jugador[] jugadores;
	private Jugador jugador;
	
	public CompetenciaJugador(String nombre, String pista, Jugador[] jugadores, Jugador jugador) {
		super(nombre, pista);
		this.jugadores = jugadores;
		this.jugador = jugador;
	}
	
	public Jugador[] getJugadores() {
		return jugadores;
	}
	public void setJugadores(Jugador[] jugadores) {
		this.jugadores = jugadores;
	}
	public Jugador getJugador() {
		return jugador;
	}
	public void setJugador(Jugador jugador) {
		this.jugador = jugador;
	}
	
	
}
