package principal;

public interface Iprueba {
	
	public void imprimir(String s);
}
