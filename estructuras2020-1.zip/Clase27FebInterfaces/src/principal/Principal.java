package principal;

public class Principal {
 
	public static void main(String[] args) {
		
		Prueba2 p1=new Prueba2();
		Prueba2 p2=new Prueba2();
		Iprueba arr[] = new Iprueba[2];
		
		arr[0]=p1;
		arr[1]=p2;
		
		
	}
}
