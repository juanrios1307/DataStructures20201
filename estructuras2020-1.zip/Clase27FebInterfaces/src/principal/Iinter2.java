package principal;

public interface Iinter2 {
	
	public void met1();
}
