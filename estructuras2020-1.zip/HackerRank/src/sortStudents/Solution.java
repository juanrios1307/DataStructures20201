package sortStudents;

import java.math.BigInteger;
import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;


/*5
33 Rumpa 3.68
85 Ashis 3.85
56 Samiha 3.75
19 Samara 3.75
22 Fahim 3.76*/

//Complete the code
public class Solution
{
	public static void main(String[] args){
		/*Scanner in = new Scanner(System.in);
		int testCases = Integer.parseInt(in.nextLine());
		
		List<Student> studentList = new ArrayList<Student>();
		while(testCases>0){
			int id = in.nextInt();
			String fname = in.next();
			double cgpa = in.nextDouble();
			
			Student st = new Student(id, fname, cgpa);
			studentList.add(st);
			testCases--;
		}
		
		in.close();*/
		
		//Student[] lista=new Student[studentList.size()];
		Comparable[] lista= {"Rumpa","Ashis","Samiha","Samara","Fahim"};
		
		/*for(int i=0; i< studentList.size();i++){
			lista[i]=studentList.get(i);
			
		}*/
		String s="Hello";
		
		
		printLista(mergeSort(lista));
		
	}
	
	
	public static void printLista(Comparable[] lista) {
		for (Comparable i:lista) {
			System.out.println(i+"\t");
		}
		System.out.println();
	}

	  public static Comparable[] mergeSort(Comparable[] lista ){
		  if(lista.length==1) {
			  return lista;
		  }else {
			  int mitad=(lista.length)/2;
			  
			  Comparable[] left=Arrays.copyOfRange(lista, 0, mitad);
			  Comparable[] right=Arrays.copyOfRange(lista, mitad, lista.length);
			  
			  
			  return merge(mergeSort(left), mergeSort(right));
			  
		  }
	  }

	  
	  public static Comparable[] merge(Comparable[] a,Comparable[] b){
		  Comparable[] lista=new Comparable[a.length+b.length];
		  int i=0,j=0;
		  
		  while(i<a.length && j<b.length) 
			  lista[i+j]=a[i].compareTo(b[j])<=0?a[i++]:b[j++];
			  
		  for (int k = i; k < a.length; k++) {
			  lista[k+j]=a[k];
		  }
		  
		  for (int k = j; k < b.length; k++) {
			lista[k+i]=b[k];
		  }
		  
		  return lista;

	  }
	  
	  
}
