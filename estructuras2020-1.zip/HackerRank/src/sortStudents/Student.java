package sortStudents;

import java.util.*;

class Student implements Comparable<Student>{
	private int id;
	private String fname;
	private double cgpa;
	public Student(int id, String fname, double cgpa) {
		super();
		this.id = id;
		this.fname = fname;
		this.cgpa = cgpa;
	}
	public int getId() {
		return id;
	}
	public String getFname() {
		return fname;
	}
	public double getCgpa() {
		return cgpa;
	}
	
	@Override
    public int compareTo(Student s){
        return fname.compareTo(s.getFname());
    }
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return fname;
	}
	
	
}


