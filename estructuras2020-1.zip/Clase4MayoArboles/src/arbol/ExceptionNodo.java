package arbol;

class ExceptionNodo extends Exception{
    public ExceptionNodo(String s){
        super(s);
    }
}